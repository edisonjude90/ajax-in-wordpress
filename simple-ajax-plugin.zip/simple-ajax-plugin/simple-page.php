<div>
<h1>
		hello world
</h1>
<?php
	echo "this is my page";
?>
</div>